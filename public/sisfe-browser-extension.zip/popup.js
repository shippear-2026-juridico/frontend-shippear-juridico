const render = ({ stage = "SIN ACTIVIDAD", message = "Iniciá la conexión desde el gestor.", updatedAt } = {}) => {
  document.querySelector("#stage").textContent = stage
  document.querySelector("#message").textContent = message
  document.querySelector("#time").textContent = updatedAt ? new Date(updatedAt).toLocaleString("es-AR") : ""
}
chrome.storage.local.get("connectorStatus").then(({ connectorStatus }) => render(connectorStatus))
chrome.storage.onChanged.addListener((changes) => { if (changes.connectorStatus) render(changes.connectorStatus.newValue) })
document.querySelector("#clear").addEventListener("click", () => chrome.storage.local.remove("connectorStatus").then(() => render()))
