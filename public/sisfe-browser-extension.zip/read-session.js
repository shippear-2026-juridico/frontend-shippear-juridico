(() => {
  const publishStoredSession = () => {
    try {
      const currentUser = JSON.parse(localStorage.getItem("currentUser") || "null")
      if (typeof currentUser?.token === "string") {
        window.postMessage({ source: "roxium-sisfe-page", type: "STORED_SESSION", token: currentUser.token }, "*")
      }
    } catch {}
  }
  window.addEventListener("message", (event) => {
    if (event.source === window && event.data?.source === "roxium-sisfe-extension" && event.data?.type === "READ_STORED_SESSION") {
      publishStoredSession()
    }
  })
})()
