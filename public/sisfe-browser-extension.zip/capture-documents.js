(() => {
  const BACKEND_URL = "https://backend-sistema-juridico-production.up.railway.app"
  let ticket = ""
  const uploading = new Set()
  let authorizationTimer = null
  let queuePaused = false
  let resumeWaiters = []
  let queueHandedOff = false
  let awaitingAuthorization = false
  let rearmAuthorization = null

  const publish = (type, message, extra = {}) => window.postMessage({ source: "roxium-sisfe-capture", type, message, ...extra }, "*")

  // El estado real de la cola llega por mensaje desde el bridge. Hasta que llegue no sabemos
  // si estamos pausados, así que nadie puede arrancar: asumir "despausado" hacía que la
  // extensión siguiera descargando después de pausar.
  let markQueueStateKnown = () => {}
  const queueStateKnown = new Promise((resolve) => { markQueueStateKnown = resolve })
  setTimeout(markQueueStateKnown, 5000)

  const setQueuePaused = (paused) => {
    queuePaused = Boolean(paused)
    markQueueStateKnown()
    if (queuePaused) return
    const waiters = resumeWaiters
    resumeWaiters = []
    // Avisamos que esta pestaña retoma por su cuenta para que el service worker no
    // navegue en paralelo y pise el trabajo en curso.
    if (waiters.length || awaitingAuthorization) publish("QUEUE_TOOK_OVER", "Retomando el documento que había quedado en curso…")
    waiters.forEach((resolve) => resolve())
    if (awaitingAuthorization && rearmAuthorization) rearmAuthorization()
  }

  const waitUntilQueueResumed = async () => {
    await queueStateKnown
    if (!queuePaused) return
    publish("QUEUE_PAUSED", "Sincronización pausada. El documento actual se conservará para retomarlo después.")
    return new Promise((resolve) => resumeWaiters.push(resolve))
  }

  const continueQueue = (nextUrl, delay = 1200) => {
    if (!nextUrl) return
    setTimeout(() => {
      if (queueHandedOff) return
      if (queuePaused) {
        queueHandedOff = true
        publish("QUEUE_RESUME_READY", "El próximo documento quedó guardado para cuando retomes.", { nextUrl })
        return
      }
      location.assign(nextUrl)
    }, delay)
  }

  const describe = (value) => {
    try {
      const url = new URL(String(value), location.href)
      if (url.pathname.endsWith("/actuaciones/findDocumentoAdjuntoById")) {
        const externalId = url.searchParams.get("idActuacion")
        return externalId ? { source: "ACTUACION", externalId } : null
      }
      if (url.pathname.endsWith("/cargos/findDocumentoAdjuntoByAdjuntoCargoId")) {
        const externalId = url.searchParams.get("idAdjuntoCargo")
        return externalId ? { source: "CARGO", externalId } : null
      }
    } catch {}
    return null
  }

  const fileName = (disposition, descriptor) => {
    const utf = String(disposition || "").match(/filename\*=UTF-8''([^;]+)/i)
    const plain = String(disposition || "").match(/filename="?([^";]+)"?/i)
    try { return decodeURIComponent(utf?.[1] || plain?.[1] || `documento-${descriptor.externalId}.pdf`) } catch { return `documento-${descriptor.externalId}.pdf` }
  }

  const autoTarget = (() => {
    const params = new URLSearchParams(location.search)
    const source = params.get("roxium_source")
    const externalId = params.get("roxium_external_id")
    return params.get("roxium_autodownload") === "1" && ["ACTUACION", "CARGO"].includes(source) && externalId
      ? { source, externalId, autorun: params.get("roxium_autorun") === "1" }
      : null
  })()

  if (autoTarget) {
    const saveDirectlyToRoxium = (blob, name = "documento.pdf") => {
      if (!(blob instanceof Blob) || !blob.size) {
        publish("AUTO_DOWNLOAD_ERROR", "SISFE devolvió un documento vacío", { externalId: autoTarget.externalId })
        return
      }
      const disposition = `attachment; filename*=UTF-8''${encodeURIComponent(name)}`
      void upload(blob, autoTarget, disposition)
    }
    saveDirectlyToRoxium.saveAs = saveDirectlyToRoxium
    window.saveAs = saveDirectlyToRoxium
  }

  const normalize = (value) => String(value || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().toLocaleLowerCase("es")

  const sisfeToken = () => {
    try { return JSON.parse(localStorage.getItem("currentUser") || "null")?.token || "" } catch { return "" }
  }

  const officialJson = async (path) => {
    const token = sisfeToken()
    if (!token) throw new Error("No se encontró una sesión activa de SISFE")
    const response = await originalFetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
    })
    if (!response.ok) throw new Error(`SISFE respondió HTTP ${response.status}`)
    return response.json()
  }

  const matchingRow = (record, index) => {
    const rows = [...document.querySelectorAll("app-grilla table tbody tr")]
    if (!rows.length) return null
    const labels = autoTarget.source === "CARGO"
      ? [record?.adjunto, record?.fecha]
      : [record?.novedad, record?.fecha, record?.observacion]
    const usefulLabels = labels.map(normalize).filter((label) => label.length >= 4)
    const scored = rows.map((row) => ({ row, score: usefulLabels.filter((label) => normalize(row.textContent).includes(label)).length }))
      .sort((left, right) => right.score - left.score)
    if (scored[0]?.score >= Math.min(2, usefulLabels.length)) return scored[0].row
    return index >= 0 && index < rows.length ? rows[index] : null
  }

  const waitForDownloadButton = (record, index) => new Promise((resolve, reject) => {
    const startedAt = Date.now()
    const inspect = () => {
      const row = matchingRow(record, index)
      const buttons = row ? [...row.querySelectorAll("button")].filter((button) => button.querySelector(".fa-paperclip")) : []
      const button = autoTarget.source === "ACTUACION" ? buttons[0] : buttons.at(-1)
      if (button) return resolve(button)
      if (Date.now() - startedAt > 30_000) return reject(new Error("No se encontró el clip del documento en la pantalla de SISFE"))
      setTimeout(inspect, 400)
    }
    inspect()
  })

  const startAutomaticDownload = async () => {
    if (!autoTarget) return
    try {
      while (!ticket) await new Promise((resolve) => setTimeout(resolve, 100))
      await waitUntilQueueResumed()
      let result
      if (autoTarget.source === "CARGO") {
        const cargoId = location.pathname.split("/").filter(Boolean).at(-2)
        result = await officialJson(`/cargos/findDocumentosAdjuntosById?idCargo=${encodeURIComponent(cargoId)}`)
      } else {
        const expedienteId = location.pathname.split("/").filter(Boolean).at(-1)
        result = await officialJson(`/expedientes/findNovedadesById?idExpediente=${encodeURIComponent(expedienteId)}&page=1&size=1000`)
      }
      const list = Array.isArray(result?.lista) ? result.lista : []
      const idField = autoTarget.source === "CARGO" ? "idAdjuntoCargo" : "id"
      const index = list.findIndex((item) => String(item?.[idField]) === autoTarget.externalId)
      if (index < 0) throw new Error("SISFE no devolvió el documento pendiente solicitado")
      const button = await waitForDownloadButton(list[index], index)
      await waitUntilQueueResumed()
      publish("DOCUMENT_AUTHORIZING", `Solicitando a SISFE el documento ${autoTarget.externalId}…`, { externalId: autoTarget.externalId })
      // Si la pausa cae en el medio de la autorización hay que volver a pedirla al retomar:
      // antes el timer se descartaba y el documento quedaba huérfano, sin click ni timer.
      const armAuthorization = () => {
        clearTimeout(authorizationTimer)
        awaitingAuthorization = true
        authorizationTimer = setTimeout(() => {
          if (queuePaused) {
            publish("QUEUE_PAUSED", "Sincronización pausada mientras SISFE autorizaba el documento.", { externalId: autoTarget.externalId })
            return
          }
          awaitingAuthorization = false
          publish("AUTO_DOWNLOAD_ERROR", "SISFE no entregó el PDF dentro de los 45 segundos", { externalId: autoTarget.externalId })
        }, 45_000)
        setTimeout(() => { if (!queuePaused) button.click() }, 350)
      }
      rearmAuthorization = armAuthorization
      armAuthorization()
    } catch (error) {
      awaitingAuthorization = false
      publish("AUTO_DOWNLOAD_ERROR", error instanceof Error ? error.message : String(error), { externalId: autoTarget.externalId })
    }
  }

  const sendToRoxium = (blob, descriptor, name, attempt, maxAttempts) => new Promise((resolve, reject) => {
    const request = new XMLHttpRequest()
    let settled = false
    let inactivityTimer
    const finish = (callback, value) => {
      if (settled) return
      settled = true
      clearTimeout(inactivityTimer)
      callback(value)
    }
    const resetInactivityTimer = () => {
      clearTimeout(inactivityTimer)
      inactivityTimer = setTimeout(() => {
        const error = new Error("La subida no avanzó durante 30 segundos")
        error.retryable = true
        request.abort()
        finish(reject, error)
      }, 30_000)
    }
    request.open("POST", `${BACKEND_URL}/api/integrations/sisfe/browser-capture/document`)
    request.setRequestHeader("Content-Type", blob.type || "application/pdf")
    request.setRequestHeader("x-sisfe-ticket", ticket)
    request.setRequestHeader("x-document-source", descriptor.source)
    request.setRequestHeader("x-document-external-id", descriptor.externalId)
    let lastPercentage = -1
    request.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) return
      resetInactivityTimer()
      const percentage = Math.round((event.loaded / event.total) * 100)
      if (percentage === lastPercentage) return
      lastPercentage = percentage
      publish("DOCUMENT_UPLOADING", `Guardando ${name} en Roxium…`, {
        externalId: descriptor.externalId, fileName: name, completed: event.loaded, total: event.total,
        progressKind: "bytes", attempt, maxAttempts,
      })
    })
    request.addEventListener("load", () => {
      const result = (() => { try { return JSON.parse(request.responseText || "{}") } catch { return {} } })()
      if (request.status >= 200 && request.status < 300) return finish(resolve, result)
      const error = new Error(result.error || `Roxium respondió HTTP ${request.status}`)
      error.retryable = request.status === 408 || request.status === 429 || request.status >= 500
      finish(reject, error)
    })
    request.addEventListener("error", () => {
      const error = new Error("No se pudo conectar con Roxium")
      error.retryable = true
      finish(reject, error)
    })
    resetInactivityTimer()
    request.send(blob)
  })

  const reportFailedDocument = async (descriptor, errorMessage) => {
    let lastError
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-capture/document-failure`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ticket, source: descriptor.source, externalId: descriptor.externalId, errorMessage }),
        })
        const result = await response.json().catch(() => ({}))
        if (!response.ok) throw new Error(result.error || `Roxium respondió HTTP ${response.status}`)
        return result
      } catch (error) {
        lastError = error
        if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, attempt * 2000))
      }
    }
    throw lastError || new Error("No se pudo registrar el documento fallido")
  }

  const upload = async (blob, descriptor, disposition = "") => {
    if (!ticket || !(blob instanceof Blob) || !blob.size) return
    if (authorizationTimer) clearTimeout(authorizationTimer)
    authorizationTimer = null
    awaitingAuthorization = false
    rearmAuthorization = null
    const key = `${descriptor.source}:${descriptor.externalId}`
    if (uploading.has(key)) return
    uploading.add(key)
    const name = fileName(disposition, descriptor)
    publish("DOCUMENT_UPLOADING", `Preparando ${name}…`, { externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size, progressKind: "bytes" })
    const maxAttempts = 4
    try {
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        await waitUntilQueueResumed()
        try {
          const result = await sendToRoxium(blob, descriptor, name, attempt, maxAttempts)
          publish("DOCUMENT_STORED", `${result.document?.fileName || name} quedó disponible en Roxium.`, { documentId: result.document?.id, fileName: result.document?.fileName || name, completed: blob.size, total: blob.size, progressKind: "bytes", attempt, maxAttempts })
          if (autoTarget?.autorun && result.nextUrl) {
            publish("DOCUMENT_AUTHORIZING", "Documento guardado. Abriendo el próximo pendiente…", { externalId: descriptor.externalId })
            continueQueue(result.nextUrl)
          }
          return
        } catch (error) {
          if (queuePaused) {
            publish("QUEUE_PAUSED", `${name} quedó en pausa y se retomará desde este mismo archivo.`, {
              externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size,
              progressKind: "bytes", attempt, maxAttempts,
            })
            await waitUntilQueueResumed()
            attempt--
            continue
          }
          if (!error?.retryable || attempt === maxAttempts) throw error
          const waitSeconds = 2 ** attempt
          publish("DOCUMENT_RETRYING", `La subida se detuvo. Reintento ${attempt + 1}/${maxAttempts} en ${waitSeconds} segundos…`, {
            externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size,
            progressKind: "bytes", attempt: attempt + 1, maxAttempts,
          })
          await new Promise((resolve) => setTimeout(resolve, waitSeconds * 1000))
        }
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      try {
        const failure = await reportFailedDocument(descriptor, errorMessage)
        publish("DOCUMENT_SKIPPED", `${name} falló después de ${maxAttempts} intentos. Quedó registrado con error y se continuará con el próximo.`, {
          externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size,
          progressKind: "bytes", maxAttempts,
        })
        if (autoTarget?.autorun && failure.nextUrl) continueQueue(failure.nextUrl, 1800)
      } catch (reportError) {
        publish("DOCUMENT_STORE_ERROR", `${errorMessage}. Además, no se pudo registrar el fallo: ${reportError instanceof Error ? reportError.message : String(reportError)}`, { externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size, progressKind: "bytes", maxAttempts })
      }
    } finally {
      // Sin esto la key quedaba trabada tras un guardado exitoso y cualquier reintento
      // posterior del mismo documento salía por el `uploading.has(key)` sin avisar nada.
      uploading.delete(key)
    }
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.data?.source !== "roxium-sisfe-extension") return
    if (event.data.type === "CAPTURE_CONFIG" && typeof event.data.ticket === "string") ticket = event.data.ticket
    if (event.data.type === "QUEUE_CONTROL") setQueuePaused(event.data.paused)
  })

  const originalFetch = window.fetch
  window.fetch = async (...args) => {
    const response = await originalFetch(...args)
    const descriptor = describe(typeof args[0] === "string" ? args[0] : args[0]?.url)
    if (descriptor && response.ok) response.clone().blob().then((blob) => upload(blob, descriptor, response.headers.get("content-disposition") || "")).catch(() => {})
    return response
  }

  const originalOpen = XMLHttpRequest.prototype.open
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__roxiumDocumentDescriptor = describe(url)
    return originalOpen.call(this, method, url, ...rest)
  }
  const originalSend = XMLHttpRequest.prototype.send
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__roxiumDocumentDescriptor) {
      this.addEventListener("load", () => {
        if (this.status < 200 || this.status >= 300) {
          if (authorizationTimer) clearTimeout(authorizationTimer)
          authorizationTimer = null
          publish("AUTO_DOWNLOAD_ERROR", `SISFE respondió HTTP ${this.status} al solicitar el PDF`, { externalId: this.__roxiumDocumentDescriptor.externalId })
          return
        }
        const blob = this.response instanceof Blob ? this.response : this.response instanceof ArrayBuffer ? new Blob([this.response], { type: "application/pdf" }) : null
        if (blob) void upload(blob, this.__roxiumDocumentDescriptor, this.getResponseHeader("content-disposition") || "")
      }, { once: true })
    }
    return originalSend.apply(this, args)
  }

  void startAutomaticDownload()
})()
