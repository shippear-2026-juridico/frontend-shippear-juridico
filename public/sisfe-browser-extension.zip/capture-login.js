(() => {
  const publish = (body) => {
    if (body && typeof body.token === "string") {
      window.postMessage({ source: "roxium-sisfe-page", type: "LOGIN_CAPTURED", token: body.token }, "*")
    }
  }

  const originalFetch = window.fetch
  window.fetch = async (...args) => {
    const response = await originalFetch(...args)
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url
    if (url?.includes("/iol/login") && response.ok) response.clone().json().then(publish).catch(() => {})
    return response
  }

  const originalOpen = XMLHttpRequest.prototype.open
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__roxiumLoginUrl = String(url)
    return originalOpen.call(this, method, url, ...rest)
  }
  const originalSend = XMLHttpRequest.prototype.send
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__roxiumLoginUrl?.includes("/iol/login")) {
      this.addEventListener("load", () => {
        if (this.status >= 200 && this.status < 300) {
          try { publish(JSON.parse(this.responseText)) } catch {}
        }
      }, { once: true })
    }
    return originalSend.apply(this, args)
  }
})()
