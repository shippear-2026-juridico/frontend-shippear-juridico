const BACKEND_URL = "https://backend-sistema-juridico-production.up.railway.app"
const FRONTEND_URL = "https://frontend-shippear-juridico-production.up.railway.app"
const runningTabs = new Set()

const setStatus = async (tabId, stage, message, extra = {}) => {
  const status = { stage, message, updatedAt: new Date().toISOString(), ...extra }
  await chrome.storage.local.set({ connectorStatus: status })
  if (tabId) chrome.tabs.sendMessage(tabId, { type: "CONNECTOR_STATUS", ...status }).catch(() => {})
}

const sisfeFetch = async (path, token) => {
  const response = await fetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  })
  if (!response.ok) throw new Error(`SISFE respondió HTTP ${response.status} en ${path.split("?")[0]}`)
  return response.json()
}

const collect = async (tabId, token) => {
  await setStatus(tabId, "SEARCHING", "Consultando la lista de expedientes en SISFE…")
  const summaries = []
  const seen = new Set()
  for (let page = 1; page <= 100; page++) {
    const result = await sisfeFetch(`/expedientes/findByFilter?page=${page}&size=100`, token)
    const list = Array.isArray(result.lista) ? result.lista : []
    for (const item of list) if (!seen.has(item.id)) { seen.add(item.id); summaries.push(item) }
    if (list.length < 100) break
  }
  if (!summaries.length) throw new Error("SISFE devolvió una lista vacía de expedientes")

  const entries = []
  const queue = [...summaries]
  let completed = 0
  const workers = Array.from({ length: 3 }, async () => {
    while (queue.length) {
      const summary = queue.shift()
      if (!summary) return
      const id = encodeURIComponent(summary.id)
      const [detail, novedades] = await Promise.all([
        sisfeFetch(`/expedientes/findById?idExpediente=${id}`, token),
        sisfeFetch(`/expedientes/findNovedadesById?idExpediente=${id}&page=1&size=1000`, token),
      ])
      entries.push({ summary, detail, movements: Array.isArray(novedades.lista) ? novedades.lista : [] })
      completed++
      await setStatus(tabId, "READING", `Leyendo expedientes: ${completed}/${summaries.length}`, { completed, total: summaries.length })
    }
  })
  await Promise.all(workers)
  return entries
}

const runImport = async (tabId, token) => {
  const key = `ticket:${tabId}`
  const stored = await chrome.storage.session.get(key)
  const ticket = stored[key]
  if (!ticket) throw new Error("No se encontró el ticket. Iniciá la conexión desde el botón del gestor.")
  const entries = await collect(tabId, token)
  await setStatus(tabId, "UPLOADING", `Preparando la importación de ${entries.length} expedientes…`, { completed: 0, total: entries.length })
  const startResponse = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, token, totalExpected: entries.length }),
  })
  const started = await startResponse.json().catch(() => ({}))
  if (!startResponse.ok) throw new Error(started.error || `El backend respondió HTTP ${startResponse.status}`)

  const batches = []
  for (let index = 0; index < entries.length; index += 5) batches.push(entries.slice(index, index + 5))
  let body = {}
  for (let index = 0; index < batches.length; index++) {
    const completed = Math.min((index + 1) * 5, entries.length)
    await setStatus(tabId, "UPLOADING", `Guardando expedientes: ${Math.min(index * 5, entries.length)}/${entries.length}`, { completed: Math.min(index * 5, entries.length), total: entries.length })
    const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/batch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ticket, importId: started.importId, entries: batches[index], isFinal: index === batches.length - 1 }),
    })
    body = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(body.error || `El backend respondió HTTP ${response.status}`)
    await setStatus(tabId, "UPLOADING", `Guardando expedientes: ${completed}/${entries.length}`, { completed, total: entries.length })
  }
  await chrome.storage.session.remove(key)
  await setStatus(tabId, "SUCCESS", `${body.syncedCount} expedientes importados correctamente.`, { completed: body.syncedCount, total: body.foundCount })
  await chrome.tabs.update(tabId, { url: `${FRONTEND_URL}/sisfe?connection=success&count=${body.syncedCount}` })
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id
  if (!tabId) return
  if (message.type === "PAIRING_TICKET" && typeof message.ticket === "string") {
    chrome.storage.session.set({ [`ticket:${tabId}`]: message.ticket })
      .then(() => setStatus(tabId, "READY", "Conector listo. Completá el login y el CAPTCHA."))
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }))
    return true
  }
  if (message.type === "PAGE_READY") {
    chrome.storage.session.get(`ticket:${tabId}`)
      .then((stored) => sendResponse({ hasTicket: Boolean(stored[`ticket:${tabId}`]) }))
      .catch(() => sendResponse({ hasTicket: false }))
    return true
  }
  if (message.type === "SISFE_TOKEN" && typeof message.token === "string") {
    if (runningTabs.has(tabId)) return
    runningTabs.add(tabId)
    setStatus(tabId, "CAPTURED", "Sesión capturada. Comenzando la lectura…")
      .then(() => runImport(tabId, message.token))
      .catch(async (error) => {
        const messageText = error instanceof Error ? error.message : String(error)
        await setStatus(tabId, "ERROR", messageText, { error: true })
        await chrome.tabs.update(tabId, { url: `${FRONTEND_URL}/sisfe?connection=error&message=${encodeURIComponent(messageText)}` })
      })
      .finally(() => runningTabs.delete(tabId))
  }
})

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ connectorStatus: { stage: "INSTALLED", message: "Conector instalado. Iniciá la conexión desde el gestor.", updatedAt: new Date().toISOString() } })
})
