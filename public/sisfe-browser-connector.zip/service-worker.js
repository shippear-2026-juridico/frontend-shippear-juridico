const BACKEND_URL = "https://backend-sistema-juridico-production.up.railway.app"
const FRONTEND_URL = "https://frontend-shippear-juridico-production.up.railway.app"
const runningTabs = new Set()

const setStatus = async (tabId, stage, message, extra = {}) => {
  const status = { stage, message, updatedAt: new Date().toISOString(), ...extra }
  await chrome.storage.local.set({ connectorStatus: status })
  if (tabId) chrome.tabs.sendMessage(tabId, { type: "CONNECTOR_STATUS", ...status }).catch(() => {})
}

const sisfeFetch = async (path, token) => {
  const response = await fetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  })
  if (!response.ok) throw new Error(`SISFE respondió HTTP ${response.status} en ${path.split("?")[0]}`)
  return response.json()
}

const isAttached = (value) => String(value || "").toUpperCase() === "SI"

const documentDate = (value) => {
  const match = String(value || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
  return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}T12:00:00-03:00` : ""
}

const safeFileName = (value, fallback) => {
  const cleaned = String(value || fallback).replace(/[\\/:*?"<>|\u0000-\u001f]/g, "-").trim().slice(0, 240)
  return cleaned || fallback
}

const responseFileName = (response, fallback) => {
  const disposition = response.headers.get("content-disposition") || ""
  const utf = disposition.match(/filename\*=UTF-8''([^;]+)/i)
  const plain = disposition.match(/filename="?([^";]+)"?/i)
  try { return safeFileName(decodeURIComponent(utf?.[1] || plain?.[1] || ""), fallback) } catch { return safeFileName(plain?.[1], fallback) }
}

const downloadSisfeDocument = async (path, token) => {
  const response = await fetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/pdf,application/octet-stream,*/*" },
  })
  if (!response.ok) {
    const error = new Error(response.status === 403
      ? "SISFE exige validación reCAPTCHA para descargar este documento"
      : `SISFE respondió HTTP ${response.status} al descargar un adjunto`)
    error.httpStatus = response.status
    throw error
  }
  const blob = await response.blob()
  if (!blob.size) throw new Error("SISFE devolvió un adjunto vacío")
  if (blob.size > 30 * 1024 * 1024) throw new Error(`El adjunto supera el límite de 30 MB (${Math.ceil(blob.size / 1024 / 1024)} MB)`)
  return { blob, response }
}

const documentKey = (document) => `${document.expedienteSisfeId}:${document.source}:${document.externalId}`

const automaticDocumentUrl = (document) => {
  if (!document?.expedienteSisfeId || !document?.externalId) return null
  const path = document.source === "CARGO" && document.movementExternalId
    ? `/documentos-adjuntos/${encodeURIComponent(document.movementExternalId)}/${encodeURIComponent(document.expedienteSisfeId)}`
    : `/detalle-expediente/${encodeURIComponent(document.expedienteSisfeId)}`
  const params = new URLSearchParams({
    roxium_autodownload: "1", roxium_autorun: "1", roxium_source: document.source,
    roxium_external_id: document.externalId,
  })
  return `https://sisfe.justiciasantafe.gov.ar${path}?${params}`
}

const registerDocumentManifest = async (tabId, ticket, importId, documents, scannedExpedienteSisfeIds) => {
  const needed = new Set()
  const batches = []
  for (let index = 0; index < documents.length; index += 100) batches.push(documents.slice(index, index + 100))
  if (!batches.length) batches.push([])
  let registered = 0
  for (let index = 0; index < batches.length; index++) {
    const batch = batches[index]
    registered += batch.length
    await setStatus(tabId, "DOCUMENTS", `Registrando adjuntos en la base: ${registered}/${documents.length}`, { completed: registered, total: documents.length })
    const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/document-manifest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ticket, importId, scannedExpedienteSisfeIds: index === 0 ? scannedExpedienteSisfeIds : [], documents: batch.map(({ path: _path, ...document }) => document) }),
    })
    const result = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(result.error || `El backend respondió HTTP ${response.status}`)
    for (const key of Array.isArray(result.needed) ? result.needed : []) needed.add(key)
  }
  return needed
}

const discoverDocuments = async (tabId, token, entries) => {
  await setStatus(tabId, "DOCUMENTS", "Buscando documentos adjuntos en las actuaciones…")
  const documents = []
  const seen = new Set()
  const cargoTasks = []
  let errors = 0
  for (const entry of entries) {
    for (const movement of entry.movements) {
      const movementId = String(movement.id || "")
      if (!movementId) continue
      if (isAttached(movement.adjunto1)) {
        const key = `ACTUACION:${entry.summary.id}:${movementId}`
        if (!seen.has(key)) {
          seen.add(key)
          documents.push({
            expedienteSisfeId: String(entry.summary.id), source: "ACTUACION", externalId: movementId,
            movementExternalId: movementId, fecha: documentDate(movement.fecha), observacion: movement.observacion || "",
            fileName: safeFileName(`${movement.novedad || "Actuación"}-${movementId}.pdf`, `actuacion-${movementId}.pdf`),
            path: `/actuaciones/findDocumentoAdjuntoById?idActuacion=${encodeURIComponent(movementId)}`,
          })
        }
      }
      if (isAttached(movement.adjunto3)) cargoTasks.push({ entry, movement, movementId })
    }
  }

  let inspected = 0
  const queue = [...cargoTasks]
  const workers = Array.from({ length: 3 }, async () => {
    while (queue.length) {
      const task = queue.shift()
      if (!task) return
      try {
        const cargo = await sisfeFetch(`/cargos/findDocumentosAdjuntosById?idCargo=${encodeURIComponent(task.movementId)}`, token)
        for (const attachment of Array.isArray(cargo.lista) ? cargo.lista : []) {
          const externalId = String(attachment.idAdjuntoCargo || "")
          if (!externalId) continue
          const key = `CARGO:${task.entry.summary.id}:${externalId}`
          if (seen.has(key)) continue
          seen.add(key)
          documents.push({
            expedienteSisfeId: String(task.entry.summary.id), source: "CARGO", externalId,
            movementExternalId: task.movementId, fecha: documentDate(attachment.fecha || task.movement.fecha),
            observacion: attachment.observacion || task.movement.observacion || "",
            fileName: safeFileName(attachment.adjunto, `adjunto-${externalId}.pdf`),
            path: `/cargos/findDocumentoAdjuntoByAdjuntoCargoId?idAdjuntoCargo=${encodeURIComponent(externalId)}`,
          })
        }
      } catch (error) {
        errors++
        console.warn("No se pudo consultar un cargo SISFE", task.movementId, error)
      }
      inspected++
      await setStatus(tabId, "DOCUMENTS", `Revisando cargos con adjuntos: ${inspected}/${cargoTasks.length}`, { completed: inspected, total: cargoTasks.length })
    }
  })
  await Promise.all(workers)
  return { documents, errors }
}

const importDocuments = async (tabId, token, ticket, importId, entries, knownPending) => {
  const discovery = await discoverDocuments(tabId, token, entries)
  const documents = discovery.documents
  const needed = await registerDocumentManifest(tabId, ticket, importId, documents, entries.map((entry) => String(entry.summary.id)))
  const combined = new Map()
  for (const document of knownPending) combined.set(documentKey(document), document)
  for (const document of documents) combined.set(documentKey(document), document)
  const pendingKeys = new Set([...knownPending.map(documentKey), ...needed])
  const pendingDocuments = [...combined.values()].filter((document) => pendingKeys.has(documentKey(document)))
  let completed = 0
  let errors = discovery.errors
  let blocked = false
  let blockedDocument = null
  let lastError = ""
  for (const document of pendingDocuments) {
    try {
      await setStatus(tabId, "DOCUMENTS", `Descargando pendientes: ${completed}/${pendingDocuments.length}`, { completed, total: pendingDocuments.length })
      const downloaded = await downloadSisfeDocument(document.path, token)
      const fallback = document.fileName.toLowerCase().endsWith(".pdf") ? document.fileName : `${document.fileName}.pdf`
      const fileName = responseFileName(downloaded.response, fallback)
      const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/document`, {
        method: "POST",
        headers: {
          "Content-Type": downloaded.blob.type || "application/pdf",
          "x-sisfe-ticket": ticket,
          "x-import-id": importId,
          "x-expediente-sisfe-id": document.expedienteSisfeId,
          "x-document-source": document.source,
          "x-document-external-id": document.externalId,
          "x-movement-external-id": document.movementExternalId,
          "x-file-name": encodeURIComponent(fileName),
          ...(document.fecha ? { "x-document-date": document.fecha } : {}),
          ...(document.observacion ? { "x-observation": encodeURIComponent(String(document.observacion).slice(0, 1000)) } : {}),
        },
        body: downloaded.blob,
      })
      const result = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(result.error || `El backend respondió HTTP ${response.status}`)
      completed++
    } catch (error) {
      errors++
      lastError = error instanceof Error ? error.message : String(error)
      console.warn("No se pudo importar un documento SISFE", document.externalId, error)
      if (error?.httpStatus === 401 || error?.httpStatus === 403) {
        blocked = true
        blockedDocument = document
        break
      }
    }
  }
  return {
    found: combined.size,
    alreadyAvailable: Math.max(0, documents.length - needed.size),
    completed,
    pending: pendingDocuments.length - completed,
    errors,
    blocked,
    blockedDocument,
    lastError,
  }
}

const collect = async (tabId, token, ticket) => {
  await setStatus(tabId, "SEARCHING", "Consultando la lista de expedientes en SISFE…")
  const summaries = []
  const seen = new Set()
  for (let page = 1; page <= 100; page++) {
    const result = await sisfeFetch(`/expedientes/findByFilter?page=${page}&size=100`, token)
    const list = Array.isArray(result.lista) ? result.lista : []
    for (const item of list) if (!seen.has(item.id)) { seen.add(item.id); summaries.push(item) }
    if (list.length < 100) break
  }
  if (!summaries.length) throw new Error("SISFE devolvió una lista vacía de expedientes")

  await setStatus(tabId, "COMPARING", "Comparando fechas de actualización con la base…")
  const planResponse = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/plan`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, summaries }),
  })
  const plan = await planResponse.json().catch(() => ({}))
  if (!planResponse.ok) throw new Error(plan.error || `El backend respondió HTTP ${planResponse.status}`)
  const refreshIds = new Set(Array.isArray(plan.refreshIds) ? plan.refreshIds : [])

  const entries = []
  const queue = summaries.filter((summary) => refreshIds.has(String(summary.id)))
  let completed = 0
  const workers = Array.from({ length: 3 }, async () => {
    while (queue.length) {
      const summary = queue.shift()
      if (!summary) return
      const id = encodeURIComponent(summary.id)
      const [detail, novedades] = await Promise.all([
        sisfeFetch(`/expedientes/findById?idExpediente=${id}`, token),
        sisfeFetch(`/expedientes/findNovedadesById?idExpediente=${id}&page=1&size=1000`, token),
      ])
      entries.push({ summary, detail, movements: Array.isArray(novedades.lista) ? novedades.lista : [] })
      completed++
      await setStatus(tabId, "READING", `Leyendo expedientes modificados: ${completed}/${queue.length + completed}`, { completed, total: refreshIds.size })
    }
  })
  await Promise.all(workers)
  const pendingDocuments = (Array.isArray(plan.pendingDocuments) ? plan.pendingDocuments : []).map((document) => ({
    ...document,
    path: document.source === "CARGO"
      ? `/cargos/findDocumentoAdjuntoByAdjuntoCargoId?idAdjuntoCargo=${encodeURIComponent(document.externalId)}`
      : `/actuaciones/findDocumentoAdjuntoById?idActuacion=${encodeURIComponent(document.externalId)}`,
  }))
  return { entries, total: summaries.length, unchangedCount: Number(plan.unchangedCount || 0), pendingDocuments }
}

const runImport = async (tabId, token) => {
  const key = `ticket:${tabId}`
  const stored = await chrome.storage.session.get(key)
  const ticket = stored[key]
  if (!ticket) throw new Error("No se encontró el ticket. Iniciá la conexión desde el botón del gestor.")
  const collection = await collect(tabId, token, ticket)
  const entries = collection.entries
  await setStatus(tabId, "UPLOADING", `Preparando ${entries.length} expedientes modificados…`, { completed: 0, total: entries.length })
  const startResponse = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, token, totalExpected: collection.total }),
  })
  const started = await startResponse.json().catch(() => ({}))
  if (!startResponse.ok) throw new Error(started.error || `El backend respondió HTTP ${startResponse.status}`)

  const batches = []
  for (let index = 0; index < entries.length; index += 5) batches.push(entries.slice(index, index + 5))
  let body = {}
  for (let index = 0; index < batches.length; index++) {
    const completed = Math.min((index + 1) * 5, entries.length)
    await setStatus(tabId, "UPLOADING", `Guardando expedientes: ${Math.min(index * 5, entries.length)}/${entries.length}`, { completed: Math.min(index * 5, entries.length), total: entries.length })
    const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/batch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ticket, importId: started.importId, entries: batches[index], isFinal: index === batches.length - 1 }),
    })
    body = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(body.error || `El backend respondió HTTP ${response.status}`)
    await setStatus(tabId, "UPLOADING", `Guardando expedientes: ${completed}/${entries.length}`, { completed, total: entries.length })
  }
  if (!batches.length) {
    const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/finish`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ticket, importId: started.importId }),
    })
    body = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(body.error || `El backend respondió HTTP ${response.status}`)
  }
  const documentResult = await importDocuments(tabId, token, ticket, started.importId, entries, collection.pendingDocuments)
  await chrome.storage.session.remove(key)
  const available = documentResult.alreadyAvailable + documentResult.completed
  const documentMessage = documentResult.pending
    ? `${documentResult.found} adjuntos registrados: ${available} disponibles y ${documentResult.pending} pendientes.${documentResult.blocked ? " SISFE exige validación reCAPTCHA para continuar." : ""}`
    : `${available} adjuntos disponibles.`
  const finalStage = documentResult.pending ? "WAITING_USER" : "SUCCESS"
  const finalMessage = documentResult.pending
    ? `La lectura de expedientes terminó. ${documentMessage} Abrí la cola y autorizá el próximo PDF desde el clip oficial de SISFE.`
    : `${body.syncedCount} expedientes actualizados y ${collection.unchangedCount} omitidos por no tener cambios. ${documentMessage}`
  await setStatus(tabId, finalStage, finalMessage, {
    completed: available, total: documentResult.found, progressKind: "documents", documents: available,
    pendingDocuments: documentResult.pending, documentErrors: documentResult.errors,
    unchangedCount: collection.unchangedCount, lastError: documentResult.lastError,
  })
  const automaticUrl = documentResult.pending ? automaticDocumentUrl(documentResult.blockedDocument || collection.pendingDocuments[0]) : null
  if (automaticUrl) {
    await setStatus(tabId, "DOCUMENT_AUTHORIZING", "La lectura terminó. Abriendo automáticamente el primer PDF pendiente…")
    await chrome.tabs.update(tabId, { url: automaticUrl })
  } else {
    await chrome.tabs.update(tabId, { url: `${FRONTEND_URL}/sisfe?connection=success&count=${body.syncedCount}&unchanged=${collection.unchangedCount}&documents=${available}&pendingDocuments=${documentResult.pending}&documentErrors=${documentResult.errors}` })
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id
  if (!tabId) return
  if (message.type === "PAIRING_TICKET" && typeof message.ticket === "string") {
    chrome.storage.session.set({ [`ticket:${tabId}`]: message.ticket, captureTicket: message.ticket })
      .then(() => setStatus(tabId, "READY", "Extensión lista. Completá el login y el CAPTCHA."))
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }))
    return true
  }
  if (message.type === "PAGE_READY") {
    chrome.storage.session.get([`ticket:${tabId}`, "captureTicket"])
      .then((stored) => sendResponse({ hasTicket: Boolean(stored[`ticket:${tabId}`]), captureTicket: stored.captureTicket || null }))
      .catch(() => sendResponse({ hasTicket: false }))
    return true
  }
  if (message.type === "DOCUMENT_CAPTURE_STATUS") {
    setStatus(tabId, message.stage || "DOCUMENT_CAPTURE", message.message || "Actualizando documento…", {
      error: Boolean(message.error), completed: message.completed, total: message.total,
      progressKind: message.progressKind, fileName: message.fileName,
    })
    sendResponse({ ok: true })
    return true
  }
  if (message.type === "SISFE_TOKEN" && typeof message.token === "string") {
    if (runningTabs.has(tabId)) return
    runningTabs.add(tabId)
    setStatus(tabId, "CAPTURED", "Sesión capturada. Comenzando la lectura…")
      .then(() => runImport(tabId, message.token))
      .catch(async (error) => {
        const messageText = error instanceof Error ? error.message : String(error)
        await setStatus(tabId, "ERROR", messageText, { error: true })
        await chrome.tabs.update(tabId, { url: `${FRONTEND_URL}/sisfe?connection=error&message=${encodeURIComponent(messageText)}` })
      })
      .finally(() => runningTabs.delete(tabId))
  }
})

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ connectorStatus: { stage: "INSTALLED", message: "Extensión instalada. Iniciá la conexión desde el gestor.", updatedAt: new Date().toISOString() } })
})
