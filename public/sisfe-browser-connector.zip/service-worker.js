const BACKEND_URL = "https://backend-sistema-juridico-production.up.railway.app"
const FRONTEND_URL = "https://frontend-shippear-juridico-production.up.railway.app"
const runningTabs = new Set()

const setStatus = async (tabId, stage, message, extra = {}) => {
  const status = { stage, message, updatedAt: new Date().toISOString(), ...extra }
  await chrome.storage.local.set({ connectorStatus: status })
  if (tabId) chrome.tabs.sendMessage(tabId, { type: "CONNECTOR_STATUS", ...status }).catch(() => {})
}

const sisfeFetch = async (path, token) => {
  const response = await fetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  })
  if (!response.ok) throw new Error(`SISFE respondió HTTP ${response.status} en ${path.split("?")[0]}`)
  return response.json()
}

const isAttached = (value) => String(value || "").toUpperCase() === "SI"

const documentDate = (value) => {
  const match = String(value || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
  return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}T12:00:00-03:00` : ""
}

const safeFileName = (value, fallback) => {
  const cleaned = String(value || fallback).replace(/[\\/:*?"<>|\u0000-\u001f]/g, "-").trim().slice(0, 240)
  return cleaned || fallback
}

const responseFileName = (response, fallback) => {
  const disposition = response.headers.get("content-disposition") || ""
  const utf = disposition.match(/filename\*=UTF-8''([^;]+)/i)
  const plain = disposition.match(/filename="?([^";]+)"?/i)
  try { return safeFileName(decodeURIComponent(utf?.[1] || plain?.[1] || ""), fallback) } catch { return safeFileName(plain?.[1], fallback) }
}

const downloadSisfeDocument = async (path, token) => {
  const response = await fetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/pdf,application/octet-stream,*/*" },
  })
  if (!response.ok) throw new Error(`SISFE respondió HTTP ${response.status} al descargar un adjunto`)
  const blob = await response.blob()
  if (!blob.size) throw new Error("SISFE devolvió un adjunto vacío")
  if (blob.size > 30 * 1024 * 1024) throw new Error(`El adjunto supera el límite de 30 MB (${Math.ceil(blob.size / 1024 / 1024)} MB)`)
  return { blob, response }
}

const discoverDocuments = async (tabId, token, entries) => {
  await setStatus(tabId, "DOCUMENTS", "Buscando documentos adjuntos en las actuaciones…")
  const documents = []
  const seen = new Set()
  const cargoTasks = []
  let errors = 0
  for (const entry of entries) {
    for (const movement of entry.movements) {
      const movementId = String(movement.id || "")
      if (!movementId) continue
      if (isAttached(movement.adjunto1)) {
        const key = `ACTUACION:${entry.summary.id}:${movementId}`
        if (!seen.has(key)) {
          seen.add(key)
          documents.push({
            expedienteSisfeId: String(entry.summary.id), source: "ACTUACION", externalId: movementId,
            movementExternalId: movementId, fecha: documentDate(movement.fecha), observacion: movement.observacion || "",
            fileName: safeFileName(`${movement.novedad || "Actuación"}-${movementId}.pdf`, `actuacion-${movementId}.pdf`),
            path: `/actuaciones/findDocumentoAdjuntoById?idActuacion=${encodeURIComponent(movementId)}`,
          })
        }
      }
      if (isAttached(movement.adjunto3)) cargoTasks.push({ entry, movement, movementId })
    }
  }

  let inspected = 0
  const queue = [...cargoTasks]
  const workers = Array.from({ length: 3 }, async () => {
    while (queue.length) {
      const task = queue.shift()
      if (!task) return
      try {
        const cargo = await sisfeFetch(`/cargos/findDocumentosAdjuntosById?idCargo=${encodeURIComponent(task.movementId)}`, token)
        for (const attachment of Array.isArray(cargo.lista) ? cargo.lista : []) {
          const externalId = String(attachment.idAdjuntoCargo || "")
          if (!externalId) continue
          const key = `CARGO:${task.entry.summary.id}:${externalId}`
          if (seen.has(key)) continue
          seen.add(key)
          documents.push({
            expedienteSisfeId: String(task.entry.summary.id), source: "CARGO", externalId,
            movementExternalId: task.movementId, fecha: documentDate(attachment.fecha || task.movement.fecha),
            observacion: attachment.observacion || task.movement.observacion || "",
            fileName: safeFileName(attachment.adjunto, `adjunto-${externalId}.pdf`),
            path: `/cargos/findDocumentoAdjuntoByAdjuntoCargoId?idAdjuntoCargo=${encodeURIComponent(externalId)}`,
          })
        }
      } catch (error) {
        errors++
        console.warn("No se pudo consultar un cargo SISFE", task.movementId, error)
      }
      inspected++
      await setStatus(tabId, "DOCUMENTS", `Revisando cargos con adjuntos: ${inspected}/${cargoTasks.length}`, { completed: inspected, total: cargoTasks.length })
    }
  })
  await Promise.all(workers)
  return { documents, errors }
}

const importDocuments = async (tabId, token, ticket, importId, entries) => {
  const discovery = await discoverDocuments(tabId, token, entries)
  const documents = discovery.documents
  let completed = 0
  let errors = discovery.errors
  for (const document of documents) {
    try {
      await setStatus(tabId, "DOCUMENTS", `Descargando y guardando adjuntos: ${completed}/${documents.length}`, { completed, total: documents.length })
      const downloaded = await downloadSisfeDocument(document.path, token)
      const fallback = document.fileName.toLowerCase().endsWith(".pdf") ? document.fileName : `${document.fileName}.pdf`
      const fileName = responseFileName(downloaded.response, fallback)
      const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/document`, {
        method: "POST",
        headers: {
          "Content-Type": downloaded.blob.type || "application/pdf",
          "x-sisfe-ticket": ticket,
          "x-import-id": importId,
          "x-expediente-sisfe-id": document.expedienteSisfeId,
          "x-document-source": document.source,
          "x-document-external-id": document.externalId,
          "x-movement-external-id": document.movementExternalId,
          "x-file-name": encodeURIComponent(fileName),
          ...(document.fecha ? { "x-document-date": document.fecha } : {}),
          ...(document.observacion ? { "x-observation": encodeURIComponent(String(document.observacion).slice(0, 1000)) } : {}),
        },
        body: downloaded.blob,
      })
      const result = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(result.error || `El backend respondió HTTP ${response.status}`)
      completed++
    } catch (error) {
      errors++
      console.warn("No se pudo importar un documento SISFE", document.externalId, error)
    }
  }
  return { found: documents.length, completed, errors }
}

const collect = async (tabId, token) => {
  await setStatus(tabId, "SEARCHING", "Consultando la lista de expedientes en SISFE…")
  const summaries = []
  const seen = new Set()
  for (let page = 1; page <= 100; page++) {
    const result = await sisfeFetch(`/expedientes/findByFilter?page=${page}&size=100`, token)
    const list = Array.isArray(result.lista) ? result.lista : []
    for (const item of list) if (!seen.has(item.id)) { seen.add(item.id); summaries.push(item) }
    if (list.length < 100) break
  }
  if (!summaries.length) throw new Error("SISFE devolvió una lista vacía de expedientes")

  const entries = []
  const queue = [...summaries]
  let completed = 0
  const workers = Array.from({ length: 3 }, async () => {
    while (queue.length) {
      const summary = queue.shift()
      if (!summary) return
      const id = encodeURIComponent(summary.id)
      const [detail, novedades] = await Promise.all([
        sisfeFetch(`/expedientes/findById?idExpediente=${id}`, token),
        sisfeFetch(`/expedientes/findNovedadesById?idExpediente=${id}&page=1&size=1000`, token),
      ])
      entries.push({ summary, detail, movements: Array.isArray(novedades.lista) ? novedades.lista : [] })
      completed++
      await setStatus(tabId, "READING", `Leyendo expedientes: ${completed}/${summaries.length}`, { completed, total: summaries.length })
    }
  })
  await Promise.all(workers)
  return entries
}

const runImport = async (tabId, token) => {
  const key = `ticket:${tabId}`
  const stored = await chrome.storage.session.get(key)
  const ticket = stored[key]
  if (!ticket) throw new Error("No se encontró el ticket. Iniciá la conexión desde el botón del gestor.")
  const entries = await collect(tabId, token)
  await setStatus(tabId, "UPLOADING", `Preparando la importación de ${entries.length} expedientes…`, { completed: 0, total: entries.length })
  const startResponse = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, token, totalExpected: entries.length }),
  })
  const started = await startResponse.json().catch(() => ({}))
  if (!startResponse.ok) throw new Error(started.error || `El backend respondió HTTP ${startResponse.status}`)

  const batches = []
  for (let index = 0; index < entries.length; index += 5) batches.push(entries.slice(index, index + 5))
  let body = {}
  for (let index = 0; index < batches.length; index++) {
    const completed = Math.min((index + 1) * 5, entries.length)
    await setStatus(tabId, "UPLOADING", `Guardando expedientes: ${Math.min(index * 5, entries.length)}/${entries.length}`, { completed: Math.min(index * 5, entries.length), total: entries.length })
    const response = await fetch(`${BACKEND_URL}/api/integrations/sisfe/browser-import/batch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ticket, importId: started.importId, entries: batches[index], isFinal: index === batches.length - 1 }),
    })
    body = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(body.error || `El backend respondió HTTP ${response.status}`)
    await setStatus(tabId, "UPLOADING", `Guardando expedientes: ${completed}/${entries.length}`, { completed, total: entries.length })
  }
  const documentResult = await importDocuments(tabId, token, ticket, started.importId, entries)
  await chrome.storage.session.remove(key)
  const documentMessage = documentResult.errors
    ? `${documentResult.completed}/${documentResult.found} adjuntos guardados; ${documentResult.errors} no pudieron descargarse.`
    : `${documentResult.completed} adjuntos guardados.`
  await setStatus(tabId, documentResult.errors ? "PARTIAL" : "SUCCESS", `${body.syncedCount} expedientes importados. ${documentMessage}`, { completed: body.syncedCount, total: body.foundCount, documents: documentResult.completed, documentErrors: documentResult.errors })
  await chrome.tabs.update(tabId, { url: `${FRONTEND_URL}/sisfe?connection=success&count=${body.syncedCount}&documents=${documentResult.completed}&documentErrors=${documentResult.errors}` })
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id
  if (!tabId) return
  if (message.type === "PAIRING_TICKET" && typeof message.ticket === "string") {
    chrome.storage.session.set({ [`ticket:${tabId}`]: message.ticket })
      .then(() => setStatus(tabId, "READY", "Conector listo. Completá el login y el CAPTCHA."))
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }))
    return true
  }
  if (message.type === "PAGE_READY") {
    chrome.storage.session.get(`ticket:${tabId}`)
      .then((stored) => sendResponse({ hasTicket: Boolean(stored[`ticket:${tabId}`]) }))
      .catch(() => sendResponse({ hasTicket: false }))
    return true
  }
  if (message.type === "SISFE_TOKEN" && typeof message.token === "string") {
    if (runningTabs.has(tabId)) return
    runningTabs.add(tabId)
    setStatus(tabId, "CAPTURED", "Sesión capturada. Comenzando la lectura…")
      .then(() => runImport(tabId, message.token))
      .catch(async (error) => {
        const messageText = error instanceof Error ? error.message : String(error)
        await setStatus(tabId, "ERROR", messageText, { error: true })
        await chrome.tabs.update(tabId, { url: `${FRONTEND_URL}/sisfe?connection=error&message=${encodeURIComponent(messageText)}` })
      })
      .finally(() => runningTabs.delete(tabId))
  }
})

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ connectorStatus: { stage: "INSTALLED", message: "Conector instalado. Iniciá la conexión desde el gestor.", updatedAt: new Date().toISOString() } })
})
