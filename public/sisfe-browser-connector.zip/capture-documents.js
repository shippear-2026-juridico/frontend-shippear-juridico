(() => {
  const BACKEND_URL = "https://backend-sistema-juridico-production.up.railway.app"
  let ticket = ""
  const uploading = new Set()

  const describe = (value) => {
    try {
      const url = new URL(String(value), location.href)
      if (url.pathname.endsWith("/actuaciones/findDocumentoAdjuntoById")) {
        const externalId = url.searchParams.get("idActuacion")
        return externalId ? { source: "ACTUACION", externalId } : null
      }
      if (url.pathname.endsWith("/cargos/findDocumentoAdjuntoByAdjuntoCargoId")) {
        const externalId = url.searchParams.get("idAdjuntoCargo")
        return externalId ? { source: "CARGO", externalId } : null
      }
    } catch {}
    return null
  }

  const fileName = (disposition, descriptor) => {
    const utf = String(disposition || "").match(/filename\*=UTF-8''([^;]+)/i)
    const plain = String(disposition || "").match(/filename="?([^";]+)"?/i)
    try { return decodeURIComponent(utf?.[1] || plain?.[1] || `documento-${descriptor.externalId}.pdf`) } catch { return `documento-${descriptor.externalId}.pdf` }
  }

  const publish = (type, message, extra = {}) => window.postMessage({ source: "roxium-sisfe-capture", type, message, ...extra }, "*")

  const autoTarget = (() => {
    const params = new URLSearchParams(location.search)
    const source = params.get("roxium_source")
    const externalId = params.get("roxium_external_id")
    return params.get("roxium_autodownload") === "1" && ["ACTUACION", "CARGO"].includes(source) && externalId
      ? { source, externalId, autorun: params.get("roxium_autorun") === "1" }
      : null
  })()

  const normalize = (value) => String(value || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().toLocaleLowerCase("es")

  const sisfeToken = () => {
    try { return JSON.parse(localStorage.getItem("currentUser") || "null")?.token || "" } catch { return "" }
  }

  const officialJson = async (path) => {
    const token = sisfeToken()
    if (!token) throw new Error("No se encontró una sesión activa de SISFE")
    const response = await originalFetch(`https://sisfe.justiciasantafe.gov.ar/iol${path}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
    })
    if (!response.ok) throw new Error(`SISFE respondió HTTP ${response.status}`)
    return response.json()
  }

  const matchingRow = (record, index) => {
    const rows = [...document.querySelectorAll("app-grilla table tbody tr")]
    if (!rows.length) return null
    const labels = autoTarget.source === "CARGO"
      ? [record?.adjunto, record?.fecha]
      : [record?.novedad, record?.fecha, record?.observacion]
    const usefulLabels = labels.map(normalize).filter((label) => label.length >= 4)
    const scored = rows.map((row) => ({ row, score: usefulLabels.filter((label) => normalize(row.textContent).includes(label)).length }))
      .sort((left, right) => right.score - left.score)
    if (scored[0]?.score >= Math.min(2, usefulLabels.length)) return scored[0].row
    return index >= 0 && index < rows.length ? rows[index] : null
  }

  const waitForDownloadButton = (record, index) => new Promise((resolve, reject) => {
    const startedAt = Date.now()
    const inspect = () => {
      const row = matchingRow(record, index)
      const buttons = row ? [...row.querySelectorAll("button")].filter((button) => button.querySelector(".fa-paperclip")) : []
      const button = autoTarget.source === "ACTUACION" ? buttons[0] : buttons.at(-1)
      if (button) return resolve(button)
      if (Date.now() - startedAt > 30_000) return reject(new Error("No se encontró el clip del documento en la pantalla de SISFE"))
      setTimeout(inspect, 400)
    }
    inspect()
  })

  const startAutomaticDownload = async () => {
    if (!autoTarget) return
    try {
      while (!ticket) await new Promise((resolve) => setTimeout(resolve, 100))
      let result
      if (autoTarget.source === "CARGO") {
        const cargoId = location.pathname.split("/").filter(Boolean).at(-2)
        result = await officialJson(`/cargos/findDocumentosAdjuntosById?idCargo=${encodeURIComponent(cargoId)}`)
      } else {
        const expedienteId = location.pathname.split("/").filter(Boolean).at(-1)
        result = await officialJson(`/expedientes/findNovedadesById?idExpediente=${encodeURIComponent(expedienteId)}&page=1&size=1000`)
      }
      const list = Array.isArray(result?.lista) ? result.lista : []
      const idField = autoTarget.source === "CARGO" ? "idAdjuntoCargo" : "id"
      const index = list.findIndex((item) => String(item?.[idField]) === autoTarget.externalId)
      if (index < 0) throw new Error("SISFE no devolvió el documento pendiente solicitado")
      const button = await waitForDownloadButton(list[index], index)
      publish("DOCUMENT_AUTHORIZING", `Solicitando a SISFE el documento ${autoTarget.externalId}…`, { externalId: autoTarget.externalId })
      const cleanUrl = `${location.pathname}${location.hash}`
      history.replaceState(history.state, "", cleanUrl)
      setTimeout(() => button.click(), 350)
    } catch (error) {
      publish("AUTO_DOWNLOAD_ERROR", error instanceof Error ? error.message : String(error), { externalId: autoTarget.externalId })
    }
  }

  const sendToRoxium = (blob, descriptor, name) => new Promise((resolve, reject) => {
    const request = new XMLHttpRequest()
    request.open("POST", `${BACKEND_URL}/api/integrations/sisfe/browser-capture/document`)
    request.setRequestHeader("Content-Type", blob.type || "application/pdf")
    request.setRequestHeader("x-sisfe-ticket", ticket)
    request.setRequestHeader("x-document-source", descriptor.source)
    request.setRequestHeader("x-document-external-id", descriptor.externalId)
    let lastPercentage = -1
    request.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) return
      const percentage = Math.round((event.loaded / event.total) * 100)
      if (percentage === lastPercentage) return
      lastPercentage = percentage
      publish("DOCUMENT_UPLOADING", `Guardando ${name} en Roxium…`, {
        externalId: descriptor.externalId, fileName: name, completed: event.loaded, total: event.total, progressKind: "bytes",
      })
    })
    request.addEventListener("load", () => {
      const result = (() => { try { return JSON.parse(request.responseText || "{}") } catch { return {} } })()
      if (request.status >= 200 && request.status < 300) resolve(result)
      else reject(new Error(result.error || `Roxium respondió HTTP ${request.status}`))
    })
    request.addEventListener("error", () => reject(new Error("No se pudo conectar con Roxium")))
    request.send(blob)
  })

  const upload = async (blob, descriptor, disposition = "") => {
    if (!ticket || !(blob instanceof Blob) || !blob.size) return
    const key = `${descriptor.source}:${descriptor.externalId}`
    if (uploading.has(key)) return
    uploading.add(key)
    const name = fileName(disposition, descriptor)
    publish("DOCUMENT_UPLOADING", `Preparando ${name}…`, { externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size, progressKind: "bytes" })
    try {
      const result = await sendToRoxium(blob, descriptor, name)
      publish("DOCUMENT_STORED", `${result.document?.fileName || name} quedó disponible en Roxium.`, { documentId: result.document?.id, fileName: result.document?.fileName || name, completed: blob.size, total: blob.size, progressKind: "bytes" })
      if (autoTarget?.autorun && result.nextUrl) {
        publish("DOCUMENT_AUTHORIZING", "Documento guardado. Abriendo el próximo pendiente…", { externalId: descriptor.externalId })
        setTimeout(() => location.assign(result.nextUrl), 1200)
      }
    } catch (error) {
      uploading.delete(key)
      publish("DOCUMENT_STORE_ERROR", error instanceof Error ? error.message : String(error), { externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size, progressKind: "bytes" })
    }
  }

  window.addEventListener("message", (event) => {
    if (event.source === window && event.data?.source === "roxium-sisfe-extension" && event.data?.type === "CAPTURE_CONFIG" && typeof event.data.ticket === "string") ticket = event.data.ticket
  })

  const originalFetch = window.fetch
  window.fetch = async (...args) => {
    const response = await originalFetch(...args)
    const descriptor = describe(typeof args[0] === "string" ? args[0] : args[0]?.url)
    if (descriptor && response.ok) response.clone().blob().then((blob) => upload(blob, descriptor, response.headers.get("content-disposition") || "")).catch(() => {})
    return response
  }

  const originalOpen = XMLHttpRequest.prototype.open
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__roxiumDocumentDescriptor = describe(url)
    return originalOpen.call(this, method, url, ...rest)
  }
  const originalSend = XMLHttpRequest.prototype.send
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__roxiumDocumentDescriptor) {
      this.addEventListener("load", () => {
        if (this.status < 200 || this.status >= 300) return
        const blob = this.response instanceof Blob ? this.response : this.response instanceof ArrayBuffer ? new Blob([this.response], { type: "application/pdf" }) : null
        if (blob) void upload(blob, this.__roxiumDocumentDescriptor, this.getResponseHeader("content-disposition") || "")
      }, { once: true })
    }
    return originalSend.apply(this, args)
  }

  void startAutomaticDownload()
})()
