(() => {
  const BACKEND_URL = "https://backend-sistema-juridico-production.up.railway.app"
  let ticket = ""
  const uploading = new Set()

  const describe = (value) => {
    try {
      const url = new URL(String(value), location.href)
      if (url.pathname.endsWith("/actuaciones/findDocumentoAdjuntoById")) {
        const externalId = url.searchParams.get("idActuacion")
        return externalId ? { source: "ACTUACION", externalId } : null
      }
      if (url.pathname.endsWith("/cargos/findDocumentoAdjuntoByAdjuntoCargoId")) {
        const externalId = url.searchParams.get("idAdjuntoCargo")
        return externalId ? { source: "CARGO", externalId } : null
      }
    } catch {}
    return null
  }

  const fileName = (disposition, descriptor) => {
    const utf = String(disposition || "").match(/filename\*=UTF-8''([^;]+)/i)
    const plain = String(disposition || "").match(/filename="?([^";]+)"?/i)
    try { return decodeURIComponent(utf?.[1] || plain?.[1] || `documento-${descriptor.externalId}.pdf`) } catch { return `documento-${descriptor.externalId}.pdf` }
  }

  const publish = (type, message, extra = {}) => window.postMessage({ source: "roxium-sisfe-capture", type, message, ...extra }, "*")

  const sendToRoxium = (blob, descriptor, name) => new Promise((resolve, reject) => {
    const request = new XMLHttpRequest()
    request.open("POST", `${BACKEND_URL}/api/integrations/sisfe/browser-capture/document`)
    request.setRequestHeader("Content-Type", blob.type || "application/pdf")
    request.setRequestHeader("x-sisfe-ticket", ticket)
    request.setRequestHeader("x-document-source", descriptor.source)
    request.setRequestHeader("x-document-external-id", descriptor.externalId)
    let lastPercentage = -1
    request.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) return
      const percentage = Math.round((event.loaded / event.total) * 100)
      if (percentage === lastPercentage) return
      lastPercentage = percentage
      publish("DOCUMENT_UPLOADING", `Guardando ${name} en Roxium…`, {
        externalId: descriptor.externalId, fileName: name, completed: event.loaded, total: event.total, progressKind: "bytes",
      })
    })
    request.addEventListener("load", () => {
      const result = (() => { try { return JSON.parse(request.responseText || "{}") } catch { return {} } })()
      if (request.status >= 200 && request.status < 300) resolve(result)
      else reject(new Error(result.error || `Roxium respondió HTTP ${request.status}`))
    })
    request.addEventListener("error", () => reject(new Error("No se pudo conectar con Roxium")))
    request.send(blob)
  })

  const upload = async (blob, descriptor, disposition = "") => {
    if (!ticket || !(blob instanceof Blob) || !blob.size) return
    const key = `${descriptor.source}:${descriptor.externalId}`
    if (uploading.has(key)) return
    uploading.add(key)
    const name = fileName(disposition, descriptor)
    publish("DOCUMENT_UPLOADING", `Preparando ${name}…`, { externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size, progressKind: "bytes" })
    try {
      const result = await sendToRoxium(blob, descriptor, name)
      publish("DOCUMENT_STORED", `${result.document?.fileName || name} quedó disponible en Roxium.`, { documentId: result.document?.id, fileName: result.document?.fileName || name, completed: blob.size, total: blob.size, progressKind: "bytes" })
    } catch (error) {
      uploading.delete(key)
      publish("DOCUMENT_STORE_ERROR", error instanceof Error ? error.message : String(error), { externalId: descriptor.externalId, fileName: name, completed: 0, total: blob.size, progressKind: "bytes" })
    }
  }

  window.addEventListener("message", (event) => {
    if (event.source === window && event.data?.source === "roxium-sisfe-extension" && event.data?.type === "CAPTURE_CONFIG" && typeof event.data.ticket === "string") ticket = event.data.ticket
  })

  const originalFetch = window.fetch
  window.fetch = async (...args) => {
    const response = await originalFetch(...args)
    const descriptor = describe(typeof args[0] === "string" ? args[0] : args[0]?.url)
    if (descriptor && response.ok) response.clone().blob().then((blob) => upload(blob, descriptor, response.headers.get("content-disposition") || "")).catch(() => {})
    return response
  }

  const originalOpen = XMLHttpRequest.prototype.open
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__roxiumDocumentDescriptor = describe(url)
    return originalOpen.call(this, method, url, ...rest)
  }
  const originalSend = XMLHttpRequest.prototype.send
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__roxiumDocumentDescriptor) {
      this.addEventListener("load", () => {
        if (this.status < 200 || this.status >= 300) return
        const blob = this.response instanceof Blob ? this.response : this.response instanceof ArrayBuffer ? new Blob([this.response], { type: "application/pdf" }) : null
        if (blob) void upload(blob, this.__roxiumDocumentDescriptor, this.getResponseHeader("content-disposition") || "")
      }, { once: true })
    }
    return originalSend.apply(this, args)
  }
})()
