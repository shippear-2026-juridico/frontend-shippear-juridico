const ticket = new URLSearchParams(location.hash.slice(1)).get("roxium_ticket")
const requestStoredToken = () => window.postMessage({ source: "roxium-sisfe-extension", type: "READ_STORED_SESSION" }, "*")
if (ticket) {
  window.postMessage({ source: "roxium-sisfe-extension", type: "CAPTURE_CONFIG", ticket }, "*")
  chrome.runtime.sendMessage({ type: "PAIRING_TICKET", ticket }).then(() => {
    requestStoredToken()
  })
}
chrome.runtime.sendMessage({ type: "PAGE_READY" }).then((response) => {
  if (response?.hasTicket) requestStoredToken()
  if (response?.captureTicket) window.postMessage({ source: "roxium-sisfe-extension", type: "CAPTURE_CONFIG", ticket: response.captureTicket }, "*")
  window.postMessage({ source: "roxium-sisfe-extension", type: "QUEUE_CONTROL", paused: Boolean(response?.queuePaused) }, "*")
})

const statusBox = document.createElement("div")
statusBox.id = "roxium-sisfe-status"
Object.assign(statusBox.style, {
  display: "none", position: "fixed", right: "20px", bottom: "20px", zIndex: "2147483647",
  maxWidth: "420px", padding: "14px 18px", borderRadius: "12px", color: "white",
  background: "#17345f", boxShadow: "0 10px 30px rgba(0,0,0,.25)", font: "14px system-ui",
})
const mountStatus = () => { if (!statusBox.isConnected) document.documentElement.appendChild(statusBox) }
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mountStatus, { once: true })
else mountStatus()

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== "roxium-sisfe-page" || !["LOGIN_CAPTURED", "STORED_SESSION"].includes(event.data?.type)) return
  chrome.runtime.sendMessage({ type: "SISFE_TOKEN", token: event.data.token })
})

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== "roxium-sisfe-capture" || event.data?.type !== "QUEUE_RESUME_READY") return
  chrome.runtime.sendMessage({ type: "QUEUE_RESUME_READY", nextUrl: event.data.nextUrl })
})

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== "roxium-sisfe-capture" || !["DOCUMENT_AUTHORIZING", "DOCUMENT_UPLOADING", "DOCUMENT_RETRYING", "DOCUMENT_SKIPPED", "DOCUMENT_STORED", "DOCUMENT_STORE_ERROR", "AUTO_DOWNLOAD_ERROR", "QUEUE_PAUSED"].includes(event.data?.type)) return
  chrome.runtime.sendMessage({
    type: "DOCUMENT_CAPTURE_STATUS", stage: event.data.type, message: event.data.message,
    error: ["DOCUMENT_STORE_ERROR", "AUTO_DOWNLOAD_ERROR"].includes(event.data.type), completed: event.data.completed,
    total: event.data.total, progressKind: event.data.progressKind, fileName: event.data.fileName,
    attempt: event.data.attempt, maxAttempts: event.data.maxAttempts,
  })
})

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "QUEUE_CONTROL") {
    window.postMessage({ source: "roxium-sisfe-extension", type: "QUEUE_CONTROL", paused: Boolean(message.paused) }, "*")
    return
  }
  if (message.type !== "CONNECTOR_STATUS") return
  mountStatus()
  statusBox.style.display = "block"
  statusBox.style.background = message.error ? "#991b1b" : "#17345f"
  statusBox.textContent = message.message
})
