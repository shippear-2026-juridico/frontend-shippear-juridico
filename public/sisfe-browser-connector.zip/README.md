# Roxium SISFE Connector

Extensión local de Chrome para conectar el login manual de SISFE con el gestor jurídico. No guarda matrícula ni contraseña y no resuelve el CAPTCHA: captura el JWT después de un ingreso exitoso, consulta SISFE desde la computadora del usuario y envía el resultado al backend mediante un ticket firmado de veinte minutos.

## Instalación local

1. Abrir `chrome://extensions`.
2. Activar **Modo desarrollador**.
3. Elegir **Cargar extensión sin empaquetar**.
4. Seleccionar esta carpeta `sisfe-browser-connector`.

Después, usar **Conectar y actualizar** desde la pantalla SISFE del gestor.

Para diagnosticar una conexión, abrir el ícono de la extensión. El panel muestra si recibió el ticket, capturó la sesión, está leyendo expedientes o recibió un error de SISFE/backend.

Si SISFE ya tiene una sesión iniciada, el conector reutiliza automáticamente el JWT vigente de `localStorage.currentUser`; no obliga a cerrar sesión ni a resolver nuevamente el CAPTCHA.

La carga al gestor se realiza en lotes de cinco expedientes para evitar cortes de conexión y mostrar progreso confirmado por el backend.
