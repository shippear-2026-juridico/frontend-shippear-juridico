# Roxium SISFE Extension

Extensión local de Chrome para conectar el login manual de SISFE con el gestor jurídico. No guarda matrícula ni contraseña y no resuelve el CAPTCHA: captura el JWT después de un ingreso exitoso, consulta SISFE desde la computadora del usuario y envía el resultado al backend mediante un ticket firmado de dos horas.

## Instalación local

1. Abrir `chrome://extensions`.
2. Activar **Modo desarrollador**.
3. Elegir **Cargar extensión sin empaquetar**.
4. Seleccionar esta carpeta `sisfe-browser-connector`.

Después, usar **Conectar y actualizar** desde la pantalla SISFE del gestor.

Para diagnosticar una conexión, abrir el ícono de la extensión. El panel muestra si recibió el ticket, capturó la sesión, está leyendo expedientes o recibió un error de SISFE/backend.

Si SISFE ya tiene una sesión iniciada, la extensión reutiliza automáticamente el JWT vigente de `localStorage.currentUser`; no obliga a cerrar sesión ni a resolver nuevamente el CAPTCHA.

La carga al gestor se realiza en lotes de cinco expedientes para evitar cortes de conexión y mostrar progreso confirmado por el backend. La versión 0.9.0 compara la fecha de actualización informada por SISFE con la guardada en la base y sólo vuelve a consultar el detalle de expedientes nuevos o modificados. También registra los documentos en el expediente correcto, omite archivos ya disponibles y conserva la cola pendiente. Al iniciar la cola desde Roxium, identifica el clip correspondiente, ejecuta la acción oficial de SISFE y, después de guardar el PDF, continúa con el próximo pendiente.

Cuando el usuario abre un adjunto y pulsa el clip de descarga en SISFE, la extensión captura esa respuesta ya autorizada por el portal y guarda el archivo en Roxium. La validación de SISFE sigue siendo manual y la extensión no intenta eludirla.
