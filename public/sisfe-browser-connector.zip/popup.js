const successStages = new Set(["SUCCESS", "DOCUMENT_STORED"])
const warningStages = new Set(["PARTIAL", "NEEDS_LOGIN", "WAITING_USER"])
const errorStages = new Set(["ERROR", "DOCUMENT_STORE_ERROR"])

const formatBytes = (value) => {
  if (value < 1024 * 1024) return `${Math.ceil(value / 1024)} KB`
  return `${(value / 1024 / 1024).toFixed(1)} MB`
}

const render = ({ stage = "SIN ACTIVIDAD", message = "Iniciá la conexión desde el gestor.", updatedAt, completed, total, progressKind, error } = {}) => {
  const safeCompleted = Number(completed)
  const safeTotal = Number(total)
  const hasProgress = Number.isFinite(safeCompleted) && Number.isFinite(safeTotal) && safeTotal > 0
  const percentage = hasProgress ? Math.max(0, Math.min(100, Math.round((safeCompleted / safeTotal) * 100))) : 0
  const tone = error || errorStages.has(stage) ? "error" : successStages.has(stage) ? "success" : warningStages.has(stage) ? "warning" : "active"
  document.body.dataset.tone = tone
  document.querySelector("#stage").textContent = stage.replaceAll("_", " ")
  document.querySelector("#message").textContent = message
  document.querySelector("#time").textContent = updatedAt ? `Actualizado ${new Date(updatedAt).toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}` : ""
  document.querySelector("#status-icon").textContent = tone === "success" ? "✓" : tone === "error" ? "!" : tone === "warning" ? "•" : "↻"
  document.querySelector("#progress-wrap").style.display = hasProgress ? "block" : "none"
  document.querySelector("#percentage").textContent = `${percentage}%`
  document.querySelector("#bar").style.width = `${percentage}%`
  document.querySelector("#progress-label").textContent = progressKind === "bytes" ? "Guardando archivo" : progressKind === "documents" ? "Documentos guardados" : "Procesando"
  const details = document.querySelector("#details")
  details.style.display = hasProgress ? "block" : "none"
  details.textContent = hasProgress
    ? progressKind === "bytes" ? `${formatBytes(safeCompleted)} de ${formatBytes(safeTotal)}` : `${safeCompleted} de ${safeTotal}`
    : ""
}

chrome.storage.local.get("connectorStatus").then(({ connectorStatus }) => render(connectorStatus))
chrome.storage.onChanged.addListener((changes) => { if (changes.connectorStatus) render(changes.connectorStatus.newValue) })
document.querySelector("#clear").addEventListener("click", () => chrome.storage.local.remove("connectorStatus").then(() => render()))
document.querySelector("#open-queue").addEventListener("click", () => chrome.tabs.create({ url: "https://frontend-shippear-juridico-production.up.railway.app/sisfe/descargas" }))
